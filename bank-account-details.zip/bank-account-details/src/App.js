import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Outlet, Link } from "react-router-dom";

function App() {
  return (
    <>
    <Navbar bg="primary" data-bs-theme="dark">
    <Container>
      <Nav className="me-auto">
        <Link to="/bankoperation">Bank Account Operation</Link>
        <Link to="/savingsgoals">Savings Goals</Link>
      </Nav>
    </Container>
  </Navbar>
  <Outlet />
  </>
  );
}

export default App;
