import React, { useState } from 'react';
import AccountDataContext from './AccountDataContext';
const SavingsGoals = () => {
  const [savingsGoal, setSavingsGoal] = useState(10000); // Savings goal amount
  const { accountDeatail } = React.useContext(AccountDataContext);

  return (
    <div className='layout-container savings-goal'>
      <h1>Savings Goals</h1>
      <label>
        Savings Goal:
        </label>
        <input
          type="number"
          value={savingsGoal}
          onChange={(e) => setSavingsGoal(Number(e.target.value))}
          required
        />
      {/* Comparison of savings goal and account balance */}
      <p>
        Comparison: {((accountDeatail.accountBalance / savingsGoal) * 100).toFixed(2)}% of goal
        reached
      </p>
    </div>
  );
};

export default SavingsGoals;