import React, {useState} from 'react';
import AccountDataContext from './AccountDataContext';

const AccountDataProvider = ({ children }) => {
  let test = {Trhistory : [{ type: 'Deposit', amount: 1000, remarks: 'Initail Deposit' }],accountBalance:1000}
  const [accountDeatail, setAccountDeatail] = useState(test);
  return (
    <AccountDataContext.Provider value={{ accountDeatail, setAccountDeatail}}>
      {children}
    </AccountDataContext.Provider>
  );
};

export default AccountDataProvider;