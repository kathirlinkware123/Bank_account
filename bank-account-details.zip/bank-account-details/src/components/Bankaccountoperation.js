import React, { useState } from 'react';
import './Bankaccountoperation.css';
import AccountDataContext from './AccountDataContext';
import Modal from 'react-modal'; 

const BankAccountOperations = () => {
    const { accountDeatail, setAccountDeatail } = React.useContext(AccountDataContext);
    const [isDepositModalOpen, setIsDepositModalOpen] = useState(false);
    const [isWithdrawModalOpen, setIsWithdrawModalOpen] = useState(false);
    
    const handleDeposit = (amount, remarks) => {
        const updatedAccountDetail = { ...accountDeatail };
        updatedAccountDetail.Trhistory.push({ type: 'Deposit', amount, remarks });
        updatedAccountDetail.accountBalance += amount;
        setAccountDeatail(updatedAccountDetail);
        setIsDepositModalOpen(false);
    };

    const handleWithdraw = (amount, remarks) => {
        if (amount > accountDeatail.accountBalance) {
            alert('Insufficient funds');
            return;
        }
        const updatedAccountDetail = {...accountDeatail};
        updatedAccountDetail.Trhistory.push(  { type: 'Withdraw', amount, remarks });
        updatedAccountDetail.accountBalance -= amount;
        setAccountDeatail(updatedAccountDetail);
        setIsWithdrawModalOpen(false);
    };

    return (
        <div className='layout-container'>
            <h1>Bank Account Operations</h1>

            <div className='account-balance'>
                <span>Account Balance: ${accountDeatail.accountBalance}</span>
            </div>

            <div className='buttons'>
                <button onClick={() => setIsDepositModalOpen(true)} className='button'>Deposit</button>
                <button onClick={() => setIsWithdrawModalOpen(true)} className='button'>Withdraw</button>
            </div>

            <div className='transaction-history'>
                <h2>Transaction History</h2>
                <table border="1">
                    <thead>
                        <tr>
                            <th>Type</th>
                            <th>Amount</th>
                            <th>Remarks</th>
                        </tr>
                    </thead>
                    <tbody>
                        {accountDeatail.Trhistory.map((transaction) => (
                            <tr key={transaction.remarks}>
                                <td>{transaction.type}</td>
                                <td>${transaction.amount}</td>
                                <td>{transaction.remarks}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
            
            {/* Deposit Modal */}
            <Modal
                isOpen={isDepositModalOpen}
                onRequestClose={() => setIsDepositModalOpen(false)}
            >
                <h2>Deposit Money</h2>
                <form onSubmit={(e) => {
                    e.preventDefault();
                    const amount = parseFloat(e.target.amount.value);
                    const remarks = e.target.remarks.value;
                    handleDeposit(amount, remarks);
                }}>
                    <label>Amount:</label>
                    <input type="number" name="amount" />
                    <br />
                    <label>Remarks:</label>
                    <textarea type="text" name="remarks" rows="2" cols="23"></textarea>
                    <br />
                    <br />
                    <button type="submit" className='button'>Deposit</button>
                </form>
            </Modal>

            {/* Withdraw Modal */}

            <Modal
                isOpen={isWithdrawModalOpen}
                onRequestClose={() => setIsWithdrawModalOpen(false)}
            >
                <h2>Withdraw Money</h2>
                <form onSubmit={(e) => {
                    e.preventDefault();
                    const amount = parseFloat(e.target.amount.value);
                    const remarks = e.target.remarks.value;
                    handleWithdraw(amount, remarks);
                }}>
                    <label>Amount:</label>
                    <input type="number" name="amount" />
                    <br />
                    <label>Remarks:</label>
                    <input type="text" name="remarks" />
                    <br />
                    <button type="submit">Withdraw</button>
                </form>
            </Modal>
        </div>
    );
};

export default BankAccountOperations;