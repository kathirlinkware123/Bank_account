import React from 'react';
const AccountDataContext = React.createContext();
export default AccountDataContext;